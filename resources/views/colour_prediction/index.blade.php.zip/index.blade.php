@extends('admin.body.adminmaster')

@section('admin')

<style>
.game-toggle {
    display: flex;
    background: #4D4D4C;
    padding: 0;
    border-radius: 10px;
    justify-content: space-around;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    overflow-x: auto;
}
.game-toggle a {
    flex: 1;
    text-align: center;
    margin: 0;
    color: #A8A5A0;
    text-decoration: none;
    font-weight: bold;
    min-width: 100px;
    transition: all 0.3s ease;
    border: 1px solid transparent;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100px;
}
.game-toggle img {
    width: 25px;
    height: 25px;
    margin-bottom: 5px;
}
.game-toggle a.active {
    background: linear-gradient(90deg, #CA9C49, #F0D58D);
    color: #905206;
    border-radius:10px;
    box-shadow: 0 2px 2px #F0D58D;
}
@media (max-width: 576px) {
    .game-toggle a {
        min-width: 120px;
    }
}
.result-card, .history-card, .future-card {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    padding: 20px;
    margin-top: 20px;
}
.result-header, .history-header, .future-header {
    background: linear-gradient(90deg, #4D4D4C, #EDD087);
    color: #fff;
    padding: 10px 20px;
    border-radius: 8px 8px 0 0;
    font-weight: bold;
    font-size: 18px;
    display: flex;
    align-items: center;
}
.future-header {
    background: linear-gradient(90deg, ##4D4D4C, #EDD087);
}
.result-header img, .future-header img {
    width: 20px;
    margin-right: 8px;
}
.period-no {
    font-size: 22px;
    font-weight: bold;
    margin: 15px 0;
    display: flex;
    align-items: center;
    justify-content: center;
}
.number-circle {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: #fff;
    border: 2px solid #ccc;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 20px;
    margin: 0 auto 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    cursor: pointer;
}
.amount-box {
    background: #f8f9fa;
    border-radius: 5px;
    text-align: center;
    padding: 5px;
    font-weight: bold;
}
</style>

<div class="container-fluid mt-3">

@if ($errors->any())
<div class="alert alert-danger">
    <ul class="mb-0">
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif

<div class="game-toggle" style="display: flex; background: #4D4D4C; padding: 0; border-radius: 10px; justify-content: space-around; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow-x: auto;">
    
    <a href="{{ route('colour_prediction', 1) }}" 
       class="{{ $gameid == 1 ? 'active' : '' }}" 
       style="flex: 1; text-align: center; margin: 0; color: #A8A5A0; text-decoration: none; font-weight: bold; min-width: 100px; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100px; transition: all 0.3s ease;" 
       onmouseover="this.style.color='white'" 
       onmouseout="this.style.color='{{ $gameid == 1 ? '#905206' : '#A8A5A0' }}'">
        <img src="{{ $gameid == 1 ? 'https://demo.globalbet786.live/game_images/wingotimergold.png' : 'https://demo.globalbet786.live/game_images/wingo_timer.png' }}" alt="icon" style="height:55px;width:65px">
        Win Go 30Sec
    </a>

    <a href="{{ route('colour_prediction', 2) }}" 
       class="{{ $gameid == 2 ? 'active' : '' }}" 
       style="flex: 1; text-align: center; margin: 0; color: #A8A5A0; text-decoration: none; font-weight: bold; min-width: 100px; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100px; transition: all 0.3s ease;" 
       onmouseover="this.style.color='white'" 
       onmouseout="this.style.color='{{ $gameid == 2 ? '#905206' : '#A8A5A0' }}'">
        <img src="{{ $gameid == 2 ? 'https://demo.globalbet786.live/game_images/wingotimergold.png' : 'https://demo.globalbet786.live/game_images/wingo_timer.png' }}" alt="icon" style="height:55px;width:65px">
        Win Go 1Min
    </a>

    <a href="{{ route('colour_prediction', 3) }}" 
       class="{{ $gameid == 3 ? 'active' : '' }}" 
       style="flex: 1; text-align: center; margin: 0; color: #A8A5A0; text-decoration: none; font-weight: bold; min-width: 100px; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100px; transition: all 0.3s ease;" 
       onmouseover="this.style.color='white'" 
       onmouseout="this.style.color='{{ $gameid == 3 ? '#905206' : '#A8A5A0' }}'">
        <img src="{{ $gameid == 3 ? 'https://demo.globalbet786.live/game_images/wingotimergold.png' : 'https://demo.globalbet786.live/game_images/wingo_timer.png' }}" alt="icon" style="height:55px;width:65px">
        Win Go 3Min
    </a>

    <a href="{{ route('colour_prediction', 4) }}" 
       class="{{ $gameid == 4 ? 'active' : '' }}" 
       style="flex: 1; text-align: center; margin: 0; color: #A8A5A0; text-decoration: none; font-weight: bold; min-width: 100px; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100px; transition: all 0.3s ease;" 
       onmouseover="this.style.color='white'" 
       onmouseout="this.style.color='{{ $gameid == 4 ? '#905206' : '#A8A5A0' }}'">
        <img src="{{ $gameid == 4 ? 'https://demo.globalbet786.live/game_images/wingotimergold.png' : 'https://demo.globalbet786.live/game_images/wingo_timer.png' }}" alt="icon" style="height:55px;width:65px">
        Win Go 5Min
    </a>

</div>

	
<div class="result-card" style="background: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); padding: 20px; margin-top: 20px;">
    <div class="result-header" style="background: linear-gradient(90deg, ##4D4D4C, #EDD087); color: #fff; padding: 10px 20px; border-radius: 8px 8px 0 0; font-weight: bold; font-size: 18px; display: flex; align-items: center;">
        <img src="https://cdn-icons-png.flaticon.com/512/3076/3076058.png" alt="icon" style="width: 20px; margin-right: 8px;">
        GAME RESULTS
    </div>

    <div class="period-no" id="periodNo" style="margin-top: 10px; font-weight: bold;">
        Period No – {{ $bets[0]->games_no }}
    </div>

    <div id="betsContainer" style="display: flex; flex-wrap: wrap; justify-content: center; margin-top: 15px;">
        @foreach ($bets as $item)
            @php $image = "https://demo.globalbet786.live/game_images/" . $item->number . ".png"; @endphp
            <div style="flex: 0 0 20%; max-width: 20%; padding: 10px; box-sizing: border-box; text-align: center;">
                <div class="number-circle" onclick="insertResult({{ $item->number }}, '{{ $item->games_no }}', {{ $gameid }}, this)" style="cursor: pointer; display: inline-block; padding: 2px; border: 2px solid transparent; border-radius: 8px;">
                    <img src="{{ $image }}" alt="Number {{ $item->number }}" style="width: 50px; height: 50px;">
                </div>
                <div class="amount-box" style="margin-top: 5px; font-weight: bold;">
                    ₹ {{ $item->amount }}
                </div>
            </div>
        @endforeach
    </div>
</div>



<div class="future-card">
    <div class="future-header">
        <img src="https://cdn-icons-png.flaticon.com/512/2088/2088617.png" alt="icon">
        SCHEDULE FUTURE RESULT
    </div>
    <form action="{{ route('scheduleFutureResult') }}" method="post" class="mt-3">
        @csrf
        <input type="hidden" name="gameid" value="{{ $gameid }}">
        <div class="row">
            <div class="col-md-4 mb-3">
                <label>Future Period</label>
                <div class="input-group">
                    <input type="text" id="futurePeriod" name="period_num" class="form-control" value="{{ $bets[0]->games_no + 1 }}">
                    <div class="input-group-append">
                        <button class="btn" style="background: linear-gradient(90deg, #4D4D4C, #E8CC85);" type="button" onclick="incrementPeriod()">+</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <label>Result</label>
                <select name="card_number" class="form-control">
                    <option value="">Select</option>
                    @for ($i = 0; $i <= 9; $i++)
                        <option value="{{ $i }}">{{ $i }}</option>
                    @endfor
                </select>
            </div>
            <div class="col-md-4 mb-3 d-flex align-items-end">
               <button class="btn btn-success w-100" style="background: linear-gradient(90deg, #4D4D4C, #E8CC85); border: none;">
    Submit
</button>

            </div>
        </div>
    </form>
</div>

<div class="history-card">
    <div class="result-header">
        <img src="https://cdn-icons-png.flaticon.com/512/1533/1533916.png" alt="icon">
        HISTORY
    </div>
    <div class="table-responsive p-3">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Period No</th>
                    <th>Set Result Number</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody id="history-body">
                {{-- History rows will be loaded by AJAX --}}
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	var baseUrl = "{{ url('/') }}";

function insertResult(number, games_no, gameid, element) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You want to insert this result!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, insert it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "{{ route('auto_wingo_result_insert') }}",
                method: 'POST',
                data: {
                    _token: "{{ csrf_token() }}",
                    gameid: gameid,
                    period_num: games_no,
                    card_number: number
                },
                success: function(response) {
                    if (response.status == 200) {
                        Swal.fire('Inserted!', 'Result inserted successfully.', 'success');
                        fetchData();
                    } else if (response.status == 409) {
                        Swal.fire('Already Set!', response.message, 'warning');
                    } else {
                        Swal.fire('Oops!', 'Something went wrong.', 'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Error occurred.', 'error');
                }
            });
        }
    });
}

function incrementPeriod() {
    var periodInput = document.getElementById('futurePeriod');
    var currentValue = parseInt(periodInput.value) || 0;
    periodInput.value = currentValue + 1;
}

function fetchData() {
    fetch('/fetch/{{ $gameid }}')
        .then(response => response.json())
        .then(data => updateBets(data.bets))
        .catch(() => console.error('Error fetching data'));
}

function updateBets(bets) {
    let betsHTML = '';
    bets.forEach(item => {
        let img = `https://demo.globalbet786.live/game_images/${item.number}.png`;
        betsHTML += `
            <div style="flex: 0 0 20%; max-width: 20%; padding: 10px; box-sizing: border-box; text-align: center;">
                <div class="number-circle" onclick="insertResult(${item.number}, '${item.games_no}', {{ $gameid }}, this)" style="cursor: pointer; display: inline-block; padding: 2px; border: 2px solid transparent; border-radius: 8px;">
                    <img src="${img}" alt="Number ${item.number}" style="width: 50px; height: 50px;">
                </div>
                <div class="amount-box" style="margin-top: 5px; font-weight: bold;">
                    ₹ ${item.amount}
                </div>
            </div>
        `;
    });
    document.getElementById('betsContainer').innerHTML = betsHTML;
    if (bets.length > 0) {
        document.getElementById('periodNo').innerHTML = 'Period No – ' + bets[0].games_no;
        document.getElementById('futurePeriod').value = parseInt(bets[0].games_no) + 1;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    fetchData();
    setInterval(fetchData, 5000);
});
	
	
	
</script>
<script>
var baseUrl = "{{ url('/') }}";

function fetchHistory() {
    fetch(baseUrl + '/api/fetch_admin_set_Results/{{ $gameid }}')
        .then(response => response.json())
        .then(data => {
            let historyHTML = '';
            data.forEach(item => {
                historyHTML += `
                   <tr class="text-center">
				<td><span class="badge bg-primary">${item.gamesno}</span></td>
				<td><span class="badge bg-success">${item.number}</span></td>
				<td><span class="badge bg-secondary">${item.created_at}</span></td>
			</tr>

                `;
            });
            document.getElementById('history-body').innerHTML = historyHTML;
        })
        .catch(() => console.error('Error fetching history'));
}

document.addEventListener('DOMContentLoaded', function() {
    fetchHistory();
    setInterval(fetchHistory, 5000);
});
</script>


@if(session('success'))
<script>
Swal.fire({ icon: 'success', title: '{{ session("success") }}', showConfirmButton: false, timer: 3000 });
</script>
@endif

@if(session('error'))
<script>
Swal.fire({ icon: 'error', title: '{{ session("error") }}', showConfirmButton: false, timer: 3000 });
</script>
@endif

@endsection
